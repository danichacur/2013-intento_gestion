﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FrbaBus.Cancelar_Viaje
{
    public partial class Baja_de_viaje : Form
    {
        public Baja_de_viaje()
        {
            InitializeComponent();
        }
    }
}
